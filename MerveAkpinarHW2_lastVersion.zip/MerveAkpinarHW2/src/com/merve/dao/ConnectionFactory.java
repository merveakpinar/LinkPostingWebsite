package com.merve.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;



public class ConnectionFactory {
	public static String URL = "jdbc:mysql://localhost/mylinksdb";
	public static String USERNAME = "root";
	public static String PASSWORD = "1234";
	public static String DRIVER_CLASS_NAME = "com.mysql.cj.jdbc.Driver";//com.mysql.jdbc.Driver";

	public static ConnectionFactory instance = new ConnectionFactory();

	private ConnectionFactory() {

		try {
			Class.forName(DRIVER_CLASS_NAME);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public Connection createConnection() {

		try {
			Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
			return conn;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;
	}

	public static Connection getConnection() {

		return instance.createConnection();

	}

}



