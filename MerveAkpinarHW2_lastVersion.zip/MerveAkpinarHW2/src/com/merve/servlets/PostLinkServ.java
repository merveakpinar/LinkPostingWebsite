package com.merve.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.merve.dao.ConnectionFactory;




@WebServlet("/postlink")
public class PostLinkServ extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		try (
				Connection conn = ConnectionFactory.getConnection();
		) {
			String query = "insert into user_links (username, postedlink,title,postdate) values(?,?,?,now());";
			PreparedStatement prepstmt = conn.prepareStatement(query);		
			HttpSession session = request.getSession(true);
			prepstmt.setString(1, (String)session.getAttribute("username"));
			prepstmt.setString(2, request.getParameter("link"));
			prepstmt.setString(3, request.getParameter("title"));
			
			int result = prepstmt.executeUpdate();
			
			response.sendRedirect("mylinks");
			
		} catch (Exception e) {

			e.printStackTrace();
		}
	}
	


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}
