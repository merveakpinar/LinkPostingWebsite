package com.merve.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.merve.dao.ConnectionFactory;
import com.merve.entities.UserLinks;




/**
 * Servlet implementation class UserLinksServlet
 */
@WebServlet("/usrlink")
public class UserLinksServ extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<UserLinks> userlinks = new ArrayList<>();
		try (Connection conn = ConnectionFactory.getConnection();
		) {
			String query = "select * from user_links where username=? order by viewcount DESC;";
			PreparedStatement prepstmt = conn.prepareStatement(query);
			
			prepstmt.setString(1, request.getParameter("user"));
			
			ResultSet rs = prepstmt.executeQuery();

			while (rs.next()) {
				userlinks.add(new UserLinks(rs.getString("username"), rs.getString("postedlink"), rs.getString("title"),
						rs.getDate("postdate"), rs.getInt("viewcount")));
			}

			request.setAttribute("userlinks", userlinks);
			request.getRequestDispatcher("userlink.jsp").forward(request, response);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}			
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}
