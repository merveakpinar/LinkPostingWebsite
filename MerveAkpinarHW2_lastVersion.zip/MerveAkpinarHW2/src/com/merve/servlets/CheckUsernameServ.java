package com.merve.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.merve.dao.ConnectionFactory;

/**
 * Servlet implementation class UsernameControlServlet
 */
@WebServlet("/checkusername")
public class CheckUsernameServ extends HttpServlet {
	
	int counter =0;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try (Connection conn = ConnectionFactory.getConnection();) {
			String query = "select * from users where username=?";
			PreparedStatement psmt = conn.prepareStatement(query);
			
			psmt.setString(1, request.getParameter("username"));
			
			ResultSet rs = psmt.executeQuery();
			while(rs.next()){
				counter++;	
			}
			if(counter > 0)
	        {
				String message = "That username already exists in the system!";  		 	
				request.setAttribute("usernameexist", message);
	            request.getRequestDispatcher("register.jsp").forward(request, response);
	        }
	        else
	        { 
	        	request.getRequestDispatcher("register").forward(request, response);
	        }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}
